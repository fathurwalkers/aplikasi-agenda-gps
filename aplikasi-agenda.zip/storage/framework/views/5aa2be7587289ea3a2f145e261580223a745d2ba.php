<?php $__env->startPush('css'); ?>
    <style>
        #mapid {
            height: 200px;
            width: 280px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
    <div class="tombol-keluar mt-2">
        <a href="<?php echo e(route('client')); ?>">
            <i class="bi bi-arrow-left-circle" style="font-size: 2rem; margin-right: 30px;"></i>
        </a>
        <h5 style="display: inline-block;">Informasi Agenda</h5>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="container">
        <div class="card text-center mb-5 shadow-sm mt-4">
            <div class="card-header">
                Informasi Agenda
            </div>
            <div class="card-body">
                <div class="container">
                    <div class="row mt-2 justify-content-center">

                        <div class="card-body text-primary">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12">

                                    <div id="mapid" width="500px" height="500px"></div>

                                    

                                </div>
                            </div>
                            <br />
                            <br />
                            <h5 class="card-title"><?php echo e($agenda->agenda_tempat); ?></h5>
                            <p class="card-text h6"><?php echo e(date('d, M Y', strtotime($agenda->agenda_waktu))); ?>

                                (<?php echo e(date('H:i', strtotime($agenda->agenda_waktu))); ?>)</p>
                            <p class="card-text h6">
                                <?php echo e($agenda->agenda_keterangan); ?>

                            </p>
                        </div>

                        <div class="col-12 mb-1 shadow-sm">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br />
    <br />
    <br />
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        // var map = L.map('mapid', {
        //     center: [<?php echo e($agenda->agenda_lat); ?>, <?php echo e($agenda->agenda_long); ?>],
        //     zoom: 13
        // });
        let mymap = L.map('mapid').setView([<?php echo e($agenda->agenda_lat); ?>, <?php echo e($agenda->agenda_long); ?>], 13);
        // let mymap = L.map('mapid').setView([-5.47486, 122.58998], 13);

        // let mymap = L.map('mapid').setView([51.505, -0.09], 13);

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png?{foo}', {foo: 'bar', attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(mymap);

        let marker = L.marker([<?php echo e($agenda->agenda_lat); ?>, <?php echo e($agenda->agenda_long); ?>]).addTo(mymap);
        // let marker = L.marker([-5.47486, 122.58998]).addTo(mymap);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-agenda\resources\views/client/client-lihat-agenda.blade.php ENDPATH**/ ?>