<?php $__env->startPush('css'); ?>
    <style>
        /* .container {
                    height: 800px!important;
                } */
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('tombol-keluar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mt-1 mb-1">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <?php if(session('status')): ?>
                <div class="alert alert-info">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="row row-cols-1  justify-content-center">

        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-10 mb-4 btn shadow ">
                <a href="<?php echo e(route('client-daftar-agenda-kategori', $item->id)); ?>">
                    <div class="card border-primary ">
                        <div class="card-body text-left">
                            <button type="button" class="btn btn-primary btn-sm">
                                <i class="bi bi-box-arrow-in-right" style="font-size: 1rem; display:inline-block;"></i>
                            </button>
                            <h6 class="card-title font-weight-bold"
                                style="font-size: 1rem; display: inline-block; margin-left: 40px;"><?php echo e($item->kategori_nama); ?></h6>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-agenda\resources\views/client/client-kategori-agenda.blade.php ENDPATH**/ ?>